package EX04to09;

public class comparadorDeAtleta implements Comparable<Atleta>
{
    @Override
    public int compareTo(Atleta o) {
        return 0;
    }
}
