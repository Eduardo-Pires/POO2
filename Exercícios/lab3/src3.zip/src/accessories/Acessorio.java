package accessories;

public interface Acessorio {
    String getTipo();
    int getQuantidade();
}
