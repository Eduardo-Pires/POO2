package motors;

public interface Motor {

    float getConsumoCombustivel();

    int getPotencia();

    String getModelo();
}
